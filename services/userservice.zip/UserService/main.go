package main

import (
	"context"
	"errors"
	"log"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/Nainyxx/market-go/services/userservice/conf"
	"github.com/Nainyxx/market-go/services/userservice/handler"
	"github.com/Nainyxx/market-go/services/userservice/repo"
	"github.com/Nainyxx/market-go/services/userservice/service"
	"github.com/gin-gonic/gin"
)

func main() {
	cfg := conf.Load()
	db, err := repo.ConnectDB(cfg.DBHost, cfg.DBPort, cfg.DBUser, cfg.DBPassword, cfg.DBName, cfg.DBSSLMode)
	if err != nil {
		log.Println(err)
		return
	}

	repo := repo.NewPostgresRepo(db)
	svc := service.NewUserService(repo)
	handler := handler.NewUserHandler(svc)

	mygin := gin.Default()
	mygin.GET("/users/:id", handler.GetUser())
	mygin.POST("/users", handler.CreateUser())
	mygin.PATCH("/users/:id", handler.UpdateUser())
	mygin.DELETE("/users/:id", handler.DeleteUser())

	mygin.PATCH("/users/:id/balance/add/:sum", handler.AddBalance())
	mygin.PATCH("/users/:id/balance/withdraw/:sum", handler.Withdraw())

	mygin.PATCH("/users/addrate/:id/:rate", handler.AddRate())

	srv := &http.Server{
		Addr:    ":" + cfg.HTTPPort,
		Handler: mygin,
	}

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	go func() {
		slog.Info("server started", "addr", srv.Addr)
		if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			slog.Error("listen", "err", err)
			stop()
		}
	}()

	<-ctx.Done()
	slog.Info("shutting down")
	shutdownCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := srv.Shutdown(shutdownCtx); err != nil {
		slog.Error("shutdown", "err", err)
	}
}
